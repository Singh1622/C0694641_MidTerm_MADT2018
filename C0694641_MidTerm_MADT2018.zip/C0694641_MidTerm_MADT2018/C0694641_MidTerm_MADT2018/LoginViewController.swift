//
//  LoginViewController.swift
//  C0694641_MidTerm_MADT2018
//
//  Created by MacStudent on 2018-02-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
   
    @IBOutlet weak var txtUserEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var myimage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    
        
    @IBOutlet weak var Login: UIButton!
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
       
        if(txtUserEmail.text == "Student@gmail.com" && txtPassword.text == "Student123")
        {
            print("Hello, My First Click : ", txtUserEmail.text! )
        }
        else{
            print("User Email / Password incorrect")
        }
        
    }
}

